package service;
import dao.DaoClass;
import bean.Customer;




public class ServiceClass implements ServiceIntf{

	DaoClass dao = new DaoClass();
	Customer cs = new Customer();
	
	@Override
	public void createAccount(Customer cs) {
		
		dao.storeDetails(cs);
		
		
	}

	@Override
	public Customer showBal(int ac_no) {
		
		cs =dao.getAccountDetails(ac_no);
		return cs;
	}

	@Override
	public Customer deposit(int account_no, double amount) {
		cs = dao.deposit(account_no, amount);
		return cs;
	}

	@Override
	public Customer withdraw(int account_no, double amount) {
		cs  = dao.withdraw(account_no, amount);
		return cs;
	}

	@Override
	public void fundTransfer(int ac1, int ac2, double amt) {
		dao.fundTransfer(ac1, ac2, amt);
		}
	public Customer getDetails(int key)
	{
		cs=dao.getDetails(key);
		return cs;
	}

}
