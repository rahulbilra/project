package dao;


import java.util.HashMap;
import java.util.Map;

import com.exceptions.InvalidAccountException;

import bean.Account;
import bean.Customer;




public class DaoClass implements DaoIntf {

	static 	Customer  c = new Customer();
	static Account acc=new Account();
	Map<Integer ,Customer > mp = new HashMap<Integer ,Customer>();
	
	@Override
	public Customer getAccountDetails(int num) {
		
		return mp.get(num);
		
			
	}

	@Override
	public void storeDetails(Customer c) {
		
	mp.put(c.getAcc().getAc_no(), c);	
	}

	@Override
	public Customer deposit(int ac_no , double amt) {
		
	c = mp.get(ac_no);
	double	tmp = c.getAcc().getAccount_balance() + amt;
		c.getAcc().setAccount_balance(tmp);
		return c;
		
	}

	@Override
	public Customer withdraw(int account_no, double amount) {

		c = mp.get(account_no);
		double temp = c.getAcc().getAccount_balance() - amount ;
		c.getAcc().setAccount_balance(temp);
		System.out.println(c);
		return c;
	}

	@Override
	public void fundTransfer(int ac1, int ac2, double amount) {

		c = mp.get(ac1);
		double temp = c.getAcc().getAccount_balance() - amount;
		c.getAcc().setAccount_balance(temp);
		
		c = mp.get(ac2);
		temp = c.getAcc().getAccount_balance() + amount;
		c.getAcc().setAccount_balance(temp);
	
		
	}

	@Override
	public Customer getDetails(int key) {

		if(mp.containsKey(key))
		{
			mp.get(key).getAcc().setAccount_no(key);
		}
		return mp.get(key);
		
		
	}

	
	
	
}
