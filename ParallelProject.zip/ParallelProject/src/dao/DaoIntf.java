package dao;


import bean.Customer;
public interface DaoIntf {
	
	Customer getAccountDetails(int num);
	void storeDetails(Customer c);
	Customer deposit(int ac_no , double amt);
	Customer withdraw(int ac_no , double amt);
	void fundTransfer(int ac1 , int ac2 , double amt);
	Customer getDetails(int num) ;

}
