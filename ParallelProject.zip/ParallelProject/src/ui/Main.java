package ui;

import bean.Account;
import service.ServiceClass;
import bean.Customer;
//import dao.DaoClass;

import java.util.Scanner;

public class Main {
	static Scanner sc = new Scanner(System.in);
	static ServiceClass service = new ServiceClass();
	static Customer c = new Customer();
	static String deposit;
	static String withdraw;
	static String fundTransfered;

	public static void showBalance() {
		System.out.println("Enter the Account number");
		int ac_no = sc.nextInt();
		c = service.getDetails(ac_no);
		// c = service.showBal(ac_no);
		System.out.println("Customer name:" + c.getcName() + "\nAccount no:" + c.getAcc().getAc_no()
				+ "\nAccount Balance " + c.getAcc().getAccount_balance());
	}

	public static void createAccount() {
		System.out.println("Enter Details");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");

		String nm = sc.nextLine();
		System.out.println("Enter Address");
		String addr = sc.nextLine();
		System.out.println("Enter Phone no");
		String num = sc.next();

		System.out.println("Enter Account type - SAVINGS or CURRENT");
		String type = sc.next();
		double balance;
		if (type.equals("SAVINGS")) {
			System.out.println("Enter the amount you want to Deposit ");
			System.out.println("Minimum amount is Rs.1000");
			balance = sc.nextDouble();
		} else {
			System.out.println("Enter the amount you want to deposit");
			balance = sc.nextDouble();
		}

		Account a1 = new Account(type, balance);
		Customer c1 = new Customer(nm, addr, num, a1);

		service.createAccount(c1);
		System.out.println(c1);
//sc.close();
	}

//--------------------------------------------------MAIN-------------------------------------------------------
	public static void main(String args[]) {
		String ch;
		do {
			System.out.println("MENU");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Transactions");
			System.out.println("7.Exit");
			int choice;
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				deposit();
				break;
			case 4:
				withdraw();
				break;
			case 5:
				fundTransfer();
				break;
			case 6:
				printTransactions();

				break;
			case 7:
				System.exit(0);
			default:
				System.out.println("Wrong choice");

			}
			System.out.println("Do you want to continue ? Y or N");
			ch = sc.next();
			// sc.close();
		} while (ch != "N");
	}

	private static void fundTransfer() {

		System.out.println("Enter the Account number from which you want to transfer amount");
		int ac1 = sc.nextInt();
		System.out.println("Enter the Account number to which you want to transfer amount");
		int ac2 = sc.nextInt();
		System.out.println("Enter the Amount");
		double amt = sc.nextDouble();
		fundTransfered = Double.toString(amt);
		service.fundTransfer(ac1, ac2, amt);
		System.out.println(service.getDetails(ac1));
		System.out.println(service.getDetails(ac2));
		service.getDetails(ac1).getAcc().setTransactionDetails("Fund transfered to " + ac2 +": "+ fundTransfered);

	}

	private static void withdraw() {
		System.out.println("ENter the Account number");
		int ac_no = sc.nextInt();
		System.out.println("Enter the amount");
		double amt = sc.nextDouble();
		withdraw = Double.toString(amt);
		c = service.withdraw(ac_no, amt);
		System.out.println(c.getAcc().getAc_no() + " has balance " +" "+ c.getAcc().getAccount_balance());
		// withdraw = c.getAcc().getAc_no() + " has balance " +
		// c.getAcc().getAccount_balance();
		service.getDetails(ac_no).getAcc().setTransactionDetails("Withdrawl Amount : " + withdraw);

	}

	private static void deposit() {
		System.out.println("Enter your Account number");
		int ac_no = sc.nextInt();
		System.out.println("Enter the Amount you want to deposit");
		double amt = sc.nextDouble();
		deposit = Double.toString(amt);
		c = service.deposit(ac_no, amt);
		System.out.println(c.getAcc().getAc_no() + " has balance " +" "+ c.getAcc().getAccount_balance());
		// deposit = c.getAcc().getAc_no() + " has balance" +
		// c.getAcc().getAccount_balance();
		service.getDetails(ac_no).getAcc().setTransactionDetails("Deposit Amount : " + deposit);

	}

	private static void printTransactions() {
		System.out.println("Enter account Number to see transactions");
		int acc_no;
		acc_no = sc.nextInt();

		System.out.println(service.getDetails(acc_no).getAcc().getTransactionDetails());

	}

}