package bean;

public class Customer {
	
	
	private String cName;
	private String addrs;
	private String phone;
	Account acc;
	public Customer()
	{
		super();
	}
	public Customer(String cName, String addrs, String phone,Account acc) {
		super();
		this.cName = cName;
		this.addrs = addrs;
		this.phone = phone;
		this.acc = acc;
	}


	public String getcName() {
		return cName;
	}


	public void setcName(String cName) {
		this.cName = cName;
	}


	public String getAddrs() {
		return addrs;
	}


	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}


	public String getPhone() {
		return phone;
	}


	public Account getAcc() {
		return acc;
	}
	
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer Name=" + cName + "\nAddress=" + addrs + "\nphoneNo=" + phone + "\naccount details:"+"\n" + acc + "";
	}
	
	
	
}
