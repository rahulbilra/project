package com.exceptions;

public class InvalidAccountException extends Exception {
	InvalidAccountException(String s)
	{
		super(s);
	}

}
